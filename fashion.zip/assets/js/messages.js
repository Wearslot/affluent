const errors = {
    ADDTOCART: "Unable to add item to cart!"
}